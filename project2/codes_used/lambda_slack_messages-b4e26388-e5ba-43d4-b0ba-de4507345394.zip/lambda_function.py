from urllib.request import Request, urlopen
from urllib.parse import urlencode
import json



def lambda_handler(event, context):
    slack_api= "https://hooks.slack.com/services/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"
    slack_data = {
        "channel":"alarms",
        "text":"You are receiving this because your Amazon CloudWatch Alarm ***IssApi*** has entered the ALARM state"
        
    }
    request = Request(slack_api, data=json.dumps(slack_data).encode(),headers = {"conetent-type":"application/json"})
    response = urlopen(request)
    

     
    return {
        'statusCode': response.getcode(),
        'body': response.read().decode()
    }
