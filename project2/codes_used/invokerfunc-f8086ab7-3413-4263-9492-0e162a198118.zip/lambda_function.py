import json
import time
import boto3
client = boto3.client('lambda')

function_name = 'arn:aws:lambda:ap-northeast-1:782483600400:function:newtest'

def lambda_handler(event, context):
    i=0
    while (i<4):
        time.sleep(15)
        i=i+1
        response = client.invoke(FunctionName = function_name)
        print(response)
      
        
  
