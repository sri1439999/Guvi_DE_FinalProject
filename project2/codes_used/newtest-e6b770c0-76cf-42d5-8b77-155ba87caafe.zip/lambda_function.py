import json
import psycopg2
import requests

conn = psycopg2.connect(host = "varahi-db1.cambobrvvnfo.ap-northeast-1.rds.amazonaws.com",port = 5432,user = "postgres",password = "aws12345")

conn.autocommit=True
cursor = conn.cursor()

#query = "create database  testdb2"
#cursor.execute(query)
#query = "create table project(SNO SERIAL PRIMARY KEY, issdata json )"
#cursor.execute(query)

def lambda_handler(event, context):


     url = "http://api.open-notify.org/iss-now.json"
     response= requests.get(url)
     k = response.text

     json_string = json.dumps(k)

     insert_query = "insert into project(issdata) values(%s)"

     cursor.execute(insert_query,(json_string,))

     cursor.execute("select * from project")

     z = cursor.fetchall()

     for i in z:
       print(i)
     return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }


print("code successfully working srinivas")

