import json
import boto3

def lambda_handler(event, context):
    
    s3_client = boto3.client('s3')
    dy_db = boto3.client('dynamodb')
    
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    obj_key = event['Records'][0]['s3']['object']['key']
    
    
    object = s3_client.get_object(Bucket =bucket,Key=obj_key)
    file = object['Body'].read().decode('utf-8')
    
    #print(file)
    
    
    dict = json.loads(file)
    
    table_name = 'general'
    table = boto3.resource('dynamodb').Table(table_name)
    table.put_item(Item=dict)
   

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
